#include "gtest/gtest.h"

int main(int argc, char* argv[]) {
    testing::InitGoogleTest(&argc, argv);
    std::cout << "AED 2023/2024 - Recitation 9" << std::endl << std::endl;
    int res = RUN_ALL_TESTS();

    return res;
}
